//Javier Guzm�n Mu�oz.
#include <iostream>
#ifndef matriz_h
#define matriz_h
const int MAX_TAM = 100;
const double C = 0.85;
struct tMatriz{
	double matriz[MAX_TAM][MAX_TAM];
	int tam;
};

struct tVector{
	double elementos[MAX_TAM];
	int tam;
};

tMatriz matrizConstante(double x, int n);
tVector operator*(tVector const & v, tMatriz const & m);
tVector operator*(double x, tVector const & m);
void normalizaL(tMatriz & L);
double operator*(tVector const& v1, tVector const& v2);
tVector operator+(tVector const& m1, tVector const & m2);
tVector vectorConstante(double x, int n);
#endif